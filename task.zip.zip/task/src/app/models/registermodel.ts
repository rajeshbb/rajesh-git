export class RegisterModel {
    id:number;
	fname :string;
	lname :string;
	username :string;
	password :string;
	email :string;
	phone:string;
	gender :string;

}
import { register } from './../../models/register';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NearlukService } from '../service/nearluk.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  display: boolean = false;

  reg: register
  click1: any = 0;
  click2: any = 0;
  options: any;

  constructor(private ats: NearlukService, private router: Router) {
    this.reg = new register()
  }

  btnAddAuthClick(myFrm: any) {
    if ((myFrm.value.Name == undefined) || (myFrm.value.Id == undefined) || (myFrm.value.password == undefined) || (myFrm.value.isd == undefined) || (myFrm.value.mobile == undefined)) {

    }
    // this.reg.mobile = this.reg.isd + this.reg.mobile
    this.ats.CheckLogin1(this.reg.username).subscribe((data) => {
      if (data.length > 0) {
        alert("user already exist...")
      }
      else {
        this.ats.AddMembers(this.reg).subscribe((data) => {
          alert("posted successfully....")
          this.router.navigate(['login'])
        })
      }
    })
  }
  cancel(){
    this.router.navigate(['home'])
  }

  ngOnInit() {
    this.ats.GetExampleDropDownisd().subscribe((data) => {
      this.options = data;
      this.display = true;


    })
    console.log(event);
  }

}

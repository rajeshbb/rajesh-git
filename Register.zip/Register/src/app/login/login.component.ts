import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  display: boolean = false;

  cncl(){
    this.display = false;
    this.router.navigate(['home'])
  }
  reg(){
    this.router.navigate(['register'])
  }
  constructor(private router: Router) { }

  ngOnInit() {
    this.display = true;
  }

}

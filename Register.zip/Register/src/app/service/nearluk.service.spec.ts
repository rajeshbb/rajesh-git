import { TestBed } from '@angular/core/testing';

import { NearlukService } from './nearluk.service';

describe('NearlukService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NearlukService = TestBed.get(NearlukService);
    expect(service).toBeTruthy();
  });
});

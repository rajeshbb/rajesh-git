import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { register } from 'src/models/register';

@Injectable({
  providedIn: 'root'
})
export class NearlukService {


  url: string = "http://localhost:4500/nearluk";

  constructor(private htc: HttpClient) { }




  CheckLogin1(username: string): Observable<any> {

    return this.htc.get(this.url + '/' + username, { responseType: 'json' });
  }

  AddMembers(reg: register): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.htc.post(this.url + '/signup', JSON.stringify(reg), httpOptions)
  }

  GetExampleDropDownisd(): Observable<any> {
    return this.htc.get(this.url+'/isd' ,{ responseType: 'json' })
  }
}

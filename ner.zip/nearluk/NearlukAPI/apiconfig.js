module.exports = {
    "name": "Nearluk",
    "db": "NearlukDB.",
    "api": "http://localhost:3400",
    "angular": "http://localhost:4200",
    "dba": "postgres://postgres:root@localhost:5432/Nearluk",
    "dbap": "postgres://postgres:root@localhost:5432/Nearluk",
    "dbad": "postgres://postgres:root@localhost:5432/Nearluk",
    "mailServer": "gmail",
    "email": "support@nearluk.com",
    "password": "support1234",
}
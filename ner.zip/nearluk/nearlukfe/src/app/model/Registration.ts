export class registration {
    name: string;
    email: string;
    mobile: any;
    Password: string;
    address: string;
    gender: string;
    occupation: string;
    roleid: number;
    dob: string;
    status: string;
    gmail_id: string;
    areaid: number;
}
export class Bidding {
    bidid:any;
    // userid: any;
    propertyid: any;
    biddingprice:any;
    biddingdate:any;
    ownerid:any;
    tenantid:any;
}
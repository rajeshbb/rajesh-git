export class postmap{
    countryname:any;
    statename:any;
    cityname:any;
    areaname:any;
    zipcode:any;
    adminsort:any;
}
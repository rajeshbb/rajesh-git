export class Login {
    emailId: string;
    Password: string;
}


export class Forgot {
    email: any;
}
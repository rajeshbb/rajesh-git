export class filters {
    propertyTypeId: any[];
    cityName: string;
    facing: any[];
    minprice: any;
    maxprice: any;
    veification: any;
    rating: any;
    propertyName: any;
    propertytype: any;

}
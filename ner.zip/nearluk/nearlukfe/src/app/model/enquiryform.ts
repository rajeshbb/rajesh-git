export class EnquiryForm {
    userid: any;
    propertytypeid: any;
    minprice: number;
    maxprice: number;
    cityname: any;
    facing: string;
    countryname: any;
    statename: any;
    areaname: any;
    countryid: number;
    stateid: number;
    cityid: number;
    areaid: number;
}



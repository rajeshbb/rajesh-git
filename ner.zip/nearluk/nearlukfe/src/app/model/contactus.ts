export class contactus {
    
    name: string;
    email: any;
    message:any;
    
}
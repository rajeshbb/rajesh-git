export class forum {
    // comment_id: string;
    propertyid: string;
    userid: number;
    comments: string;
    rating:number
    // date: string;
}
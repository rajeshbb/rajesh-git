export class property {
    userid: any;
    propertyTypeId: any;
    propertyName: any;
    facing: any;
    price: any;
    description: any;
    propertyArea: any;
    constructionStatus: any;
    securityDeposit: any;
    maintainanceCost: any;
    rentalPeriod: any;
    communityId: any;
    propertyId: any;
    available: any;
    age: any;
    facilitypost: any;


    amenitypost: any;

    address: any;
    pincode: any;
    landmarks: any;
    countryId: any;
    stateId: any;
    cityId: any;
    areaId: any;

    latitude: any;
    longitude: any;

    propertyAmenityId: any;
    amenityValue: any;

    facilityId: any;

    image: any = [];

    videos: any = [];
    preference:any;


}


export class editing {
    image: any
    path: any
}



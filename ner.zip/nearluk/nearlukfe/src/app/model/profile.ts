export class Profile {
    id: any;
    name: string;
    email: string;
    mobile: any;
    address: any;
    gender: string;
    occupation: string;
    dob: string;
    rolename: any;
    discription: any;
}
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NearlukService } from '../services/nearluk.service';

@Component({
  selector: 'app-futureproperty',
  templateUrl: './futureproperty.component.html',
  styleUrls: ['./futureproperty.component.css']
})

export class FuturepropertyComponent implements OnInit {
  featured: any;
  details: any;
  page:any=1;
  constructor(private acr: ActivatedRoute, private nearlukservice: NearlukService) { }
  moredetails(propertyid) {
    window.open('moredetails' + '/' + propertyid)
  }

  onScroll() {
    this.page = this.page + 1;
    this.infinite();
  }

  checkedd(propertyid: any, chk: any) {
    var v1 = 0
    var v2 = 0
    var v3 = 0
    if (localStorage.getItem('compare1') == propertyid) {
      v1 = 1
      v2 = 1
      v3 = 1
    }
    else if (localStorage.getItem('compare2') == propertyid && v2 == 0) {
      v1 = 1
      v2 = 1
      v3 = 1
    }
    else if (localStorage.getItem('compare3') == propertyid && v3 == 0) {
      v1 = 1
      v2 = 1
      v3 = 1
    }
    if (localStorage.getItem('compare1') == null && v1 == 0) {
      localStorage.setItem('compare1', propertyid);
    }
    else if (localStorage.getItem('compare2') == null && v2 == 0) {
      localStorage.setItem('compare2', propertyid);
      v2 = 1
    }
    else if (localStorage.getItem('compare3') == null && v3 == 0) {
      localStorage.setItem('compare3', propertyid);
      v3 = 1
    }
    else if (localStorage.getItem('compare3') != null && localStorage.getItem('compare3') == propertyid) {
      chk.checked = false;
      localStorage.removeItem('compare3');
    }
    else if (localStorage.getItem('compare1') != null && localStorage.getItem('compare1') == propertyid) {
      chk.checked = false;
      localStorage.removeItem('compare1');
    }
    else if (localStorage.getItem('compare2') != null && localStorage.getItem('compare2') == propertyid) {
      chk.checked = false;
      localStorage.removeItem('compare2');
    }
    else {
      chk.checked = false;
      alert("Excedd the limit ...")
    }
  }


  infinite(){
    
    this.nearlukservice.GetFeatured(this.featured,this.page).subscribe((data) => {
      this.details = data.data;
    })
  }
  ngOnInit() {
    this.featured = this.acr.snapshot.params.id;
    this.infinite();
  }
}



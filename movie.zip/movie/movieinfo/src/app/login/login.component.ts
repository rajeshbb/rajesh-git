import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  

  constructor(private authSer : AuthenticationService,private router:Router) {}
    
  login_Click(uname, password){
    let u  = uname.value;
    let p = password.value;
    this.authSer.AuthenticateUser(u,p).subscribe((result)=>{
      if(result.valid=="true"){
        localStorage.setItem("userid",u)
        alert("Login Success....")
      this.router.navigate(['home'])
      }
      else alert('invalid login')
      

      
    })
  }
  
  ngOnInit() {
  }

}

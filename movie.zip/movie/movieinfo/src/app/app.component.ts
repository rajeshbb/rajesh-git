import { Component , OnInit, DoCheck} from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { routerNgProbeToken } from '@angular/router/src/router_module';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,DoCheck {
  loginStatus: Observable<any>;
 
  constructor(private router:Router){}

lnkLogout_Click(){
  localStorage.removeItem("userid");
  this.router.navigate(['home']);
}
checkLocalStorage(): Observable<any> {
  return of(localStorage.getItem("userid"))
}
ngDoCheck() {
  this.checkLocalStorage().subscribe((data) => { this.loginStatus = data });
}
ngOnInit() {

}

}

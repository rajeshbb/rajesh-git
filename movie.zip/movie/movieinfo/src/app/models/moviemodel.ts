export class MovieModel {
    movieid: number;
    moviename: string;
    heroname: string;
    poster: string;
    trailer: string;
    gener:string;
}
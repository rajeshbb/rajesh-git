import { Component, OnInit } from '@angular/core';
import { MovieModel } from '../models/moviemodel';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from '../services/movie.service';

@Component({
  selector: 'app-editmovie',
  templateUrl: './editmovie.component.html',
  styleUrls: ['./editmovie.component.css']
})
export class EditmovieComponent implements OnInit {
  movieObj: MovieModel;
  
  movieinfoo: MovieModel;
  constructor(private acr:ActivatedRoute,private mService:MovieService,private rtr:Router) { 
    this.movieObj= new MovieModel();
    
  }

  editMovie(mvForm) {
    if (mvForm.valid) {
      alert(JSON.stringify(this.movieObj))
      this.mService. updateMovie(this.movieObj).subscribe((result) => {
        alert(result.message);
        this.rtr.navigate(['show-allmovies'])
      })
    }
    else {
      alert("Invalid Data ..")
    }
  }
  ngOnInit() {
    // let i: number = this.acr.snapshot.params.movieid
    // this.mService.updateMovie(i).subscribe((result) => {
    //   this.movieinfoo.movieid = result[0].movieid;
    //   this.movieinfoo.moviename = result[0].moviename;
    //   this.movieinfoo.heroname = result[0].heroname;
    //   this.movieinfoo.poster = result[0].poster;
    //   this.movieinfoo.trailer=result[0].trailer;
    //   this.movieinfoo.gener = result[0].gener
    
   }

  }



import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MovieService } from '../services/movie.service';

@Component({
  selector: 'app-show-allmovies',
  templateUrl: './show-allmovies.component.html',
  styleUrls: ['./show-allmovies.component.css']
})
export class ShowAllmoviesComponent implements OnInit {
  movies: any[] = [];
  constructor(private mService: MovieService, private rtr: Router) { }
  btnDetails(movieid: number) {
    this.rtr.navigate(['moviedetails/' + movieid])
  }

  btnDelete(movieid: number) {
    this.mService.deleteMovieById(movieid).subscribe((result) => {
      alert(result.message)
      if (result.message) {
        let dIndex = this.movies.findIndex(x => x.movieid == movieid)
        this.movies.splice(dIndex, 1)
      }
    })
  }

  btedit(movieid: number) {
    {

      this.rtr.navigate(['editmovie/' + movieid])
    }
  }

  ngOnInit() {
    this.mService.getAllMovies().subscribe((data) => {
      this.movies = data;
      console.log(JSON.stringify(this.movies))
    })
  }

}

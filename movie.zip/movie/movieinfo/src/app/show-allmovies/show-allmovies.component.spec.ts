import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllmoviesComponent } from './show-allmovies.component';

describe('ShowAllmoviesComponent', () => {
  let component: ShowAllmoviesComponent;
  let fixture: ComponentFixture<ShowAllmoviesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowAllmoviesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowAllmoviesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

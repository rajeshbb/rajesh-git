import { Component, OnInit } from '@angular/core';
import { MovieModel } from '../models/moviemodel';
import { ActivatedRoute } from '@angular/router';
import { MovieService } from '../services/movie.service';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit {
movieinfoo:MovieModel
  constructor(private acr:ActivatedRoute, private mService:MovieService) {
    this.movieinfoo=new MovieModel
   }

  ngOnInit() {
    let i: number = this.acr.snapshot.params.movieid
    this.mService.getMovieById(i).subscribe((result) => {
      this.movieinfoo.movieid = result[0].movieid;
      this.movieinfoo.moviename = result[0].moviename;
      this.movieinfoo.heroname = result[0].heroname;
      this.movieinfoo.poster = result[0].poster;
      this.movieinfoo.trailer=result[0].trailer;
      this.movieinfoo.gener = result[0].gener
    })
   }

}

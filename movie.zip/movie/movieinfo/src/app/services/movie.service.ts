import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MovieModel } from '../models/moviemodel';
import {  HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  apiUrl: string = "http://localhost:5000/movieinfoo"

  constructor(private htc: HttpClient) { }
  
  getAllMovies(): Observable<any> {
    return this.htc.get(this.apiUrl, { responseType: 'json' })
  }

  getMovieById(i : number):Observable<any> {

    return this.htc.get(this.apiUrl+'/'+i,{responseType:'json'})
   }

  deleteMovieById(movieid: number): Observable<any> {
    
    return this.htc.delete(this.apiUrl + '/' + movieid, { responseType: 'json' })

  }

  updateMovie(movieobj:MovieModel): Observable<any> { 
    const reqHeaders = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };

    return this.htc.put(this.apiUrl,JSON.stringify(movieobj), reqHeaders)
  }

  addMovie(mvObj: MovieModel): Observable<any> {
    const reqHeaders = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };

    return this.htc.post(this.apiUrl, JSON.stringify(mvObj), reqHeaders)
  }
}

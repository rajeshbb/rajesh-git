import { Component, OnInit } from '@angular/core';
import { MovieModel } from '../models/moviemodel';
import {MovieService} from '../services/movie.service'

import { Router } from '@angular/router';
import { Url } from 'url';
@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  movieObj: MovieModel;
  imgUrl:String;
  constructor(private mService: MovieService,private rtr:Router)  {
    this.movieObj = new MovieModel();
   }
   onFileSelect(event){
    if(event.target.files){
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0])
      reader.onload= (ev:any)=>{
        this.imgUrl = ev.target.result;
        this.movieObj.poster = reader.result.toString();
        this.movieObj.poster = this.movieObj.poster.replace('data:image/jpeg;base64,','') 
        this.movieObj.poster = this.movieObj.poster.replace('data:image/png;base64,','') 
        this.movieObj.poster = this.movieObj.poster.replace('data:image/jpg;base64,','')
         
        console.log(this.movieObj.poster);
      }

    }
  }

   
   SaveMovie(mvForm) {
    if (mvForm.valid) {
      // alert(JSON.stringify(this.movieObj))
      this.mService.addMovie(this.movieObj).subscribe((result) => {
        alert(result.message);
        this.rtr.navigate(['show-allmovies'])
      })
    }
    else {
      alert("Invalid Data ..")
    }
  }
  ngOnInit() {
  }

}

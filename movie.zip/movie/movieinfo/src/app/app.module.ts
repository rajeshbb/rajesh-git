import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ShowAllmoviesComponent } from './show-allmovies/show-allmovies.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { RouterModule } from '@angular/router';
import{FormsModule}from '@angular/forms';
import { EditmovieComponent } from './editmovie/editmovie.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ShowAllmoviesComponent,
    AddMovieComponent,
    MovieDetailsComponent,
    EditmovieComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
     FormsModule,

    RouterModule.forRoot([
     
      {path:"home",component:HomeComponent},
      {path:"show-allmovies",component:ShowAllmoviesComponent},
      {path:"addmovie",component:AddMovieComponent},
      {path:"moviedetails/:movieid",component:MovieDetailsComponent},
      {path:"moviedetails",component:MovieDetailsComponent},
      {path:"editmovie/:movieid",component:EditmovieComponent},
      {path:"editmovie",component:EditmovieComponent},
      {path:"login",component:LoginComponent}
      
    ]),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
